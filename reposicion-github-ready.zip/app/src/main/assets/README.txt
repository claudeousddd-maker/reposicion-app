# Reposición de Tienda — versión funcional

Esta versión es una PWA (aplicación web instalable) pensada para Android.

Incluye:
- Registro de productos con foto, nombre, código y cantidad.
- Compresión automática de fotos para ahorrar almacenamiento.
- Lista de reposición.
- Modo almacén con controles de cantidad.
- Detección de excedentes.
- Lista de devoluciones y corrección de cantidades al marcar una devolución.
- Productos no encontrados.
- Búsqueda por nombre/código y catálogo de productos usados anteriormente.
- Historial.
- Escáner de código de barras cuando el navegador/dispositivo soporta BarcodeDetector.
- Funcionamiento offline después de haber abierto la app al menos una vez y de que el service worker haya terminado de instalarse.
- Instalación como app desde el navegador cuando aparece “Instalar Reposición”.

IMPORTANTE:
1. Para cámara, escáner e instalación PWA, publícala en HTTPS. No basta con abrir index.html desde el explorador de archivos.
2. Los datos se guardan localmente en el navegador del teléfono. No hay servidor ni sincronización entre teléfonos.
3. El escáner automático depende de que el navegador soporte BarcodeDetector. Si no lo soporta, se puede escribir el código manualmente.
4. Esta versión no es todavía un APK nativo. Para convertirla en APK se puede envolver esta PWA con Capacitor/Android Studio.

Prueba recomendada:
- Agregar producto.
- Tomar foto.
- Registrar código/nombre/cantidad.
- Abrir Modo almacén.
- Subir la cantidad con +.
- Probar excedente.
- Ir a Devoluciones y marcar devuelto.
- Probar No encontrado.
- Finalizar y revisar Historial.
- Desactivar internet después de la primera carga y comprobar que la app sigue abriendo.
