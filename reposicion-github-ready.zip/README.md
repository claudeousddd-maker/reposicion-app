# Reposición - proyecto Android

Este proyecto envuelve la aplicación web incluida en `app/src/main/assets` dentro de una app Android.

## Compilar APK

Requisitos:
- Android Studio reciente
- JDK incluido por Android Studio
- Android SDK 35

Pasos:
1. Abre esta carpeta (`reposicion-apk-android`) en Android Studio.
2. Espera a que Gradle termine de sincronizar.
3. Ve a Build > Build APK(s).
4. El APK de prueba aparecerá en:
   app/build/outputs/apk/debug/app-debug.apk

La app solicita permiso de cámara para las funciones de cámara/escáner.

Nota: el proyecto usa una WebView local. Los datos de la aplicación web se guardan en el almacenamiento del WebView/teléfono.
