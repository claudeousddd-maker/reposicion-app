# Reposición — APK desde GitHub

Este proyecto está preparado para compilar el APK automáticamente con GitHub Actions.

## Desde el celular

1. Crea un repositorio nuevo en GitHub llamado `reposicion-app`.
2. Sube el contenido de esta carpeta al repositorio. Debes subir carpetas como `app`, `.github` y archivos como `build.gradle`, `settings.gradle`, etc.
3. En GitHub abre la pestaña **Actions**.
4. Selecciona **Generar APK Android**.
5. Pulsa **Run workflow**.
6. Espera a que termine.
7. Abre la ejecución terminada y descarga el artefacto **reposicion-app-debug**.
8. Dentro estará `app-debug.apk`.
9. Instálalo en tu Android.

No necesitas hosting para este método.

## Importante

El APK es una compilación de prueba (debug). Antes de usarlo diariamente conviene probar cámara, escáner, fotos, cantidades, devoluciones, historial y almacenamiento local.
